<h1 align="center">End-to-End Data Analytics Project Using Python & SQL</h1>

This repository showcases an end-to-end data analytics workflow using **Python, Pandas, and SQL Server**, based on retail order data. The project covers the complete data analytics process, from extracting and cleaning raw data to transforming it, loading it into a SQL Server database, and generating meaningful business insights through SQL analysis.

<h3>Project Overview</h3>

This project demonstrates how raw retail order data can be transformed into structured and analysis-ready information using Python and SQL. It focuses on practical data cleaning, transformation, database integration, and analytical querying.

<h3>Project Workflow</h3>

**1. Data Extraction:**
Used the Kaggle API to programmatically obtain the retail orders dataset.

**2. Data Cleaning & Preprocessing:**
Used Python and Pandas to prepare the raw dataset for analysis, including handling missing values, transforming columns, converting data types, and preparing calculated fields.

**3. Database Integration:**
Loaded the processed data into a SQL Server database for structured storage and further analysis.

**4. Data Analysis:**
Used SQL queries to explore the dataset, identify patterns and trends, perform aggregations, and generate business-oriented insights.

<h3>Project Architecture</h3>

**Workflow Breakdown:**

**Kaggle API:**
Used to retrieve the retail order dataset programmatically.

**Python + Pandas:**
Used for data preparation and transformation, including:

1. Handling missing values
2. Formatting and transforming data
3. Creating calculated columns
4. Converting data types
5. Preparing the dataset for database loading

**SQL Server:**
Used to store the processed dataset and perform structured analytical queries.

**SQL Analysis:**
Used SQL to:

1. Aggregate sales and order data
2. Analyze product and customer trends
3. Identify patterns in sales performance
4. Generate insights from the processed dataset

<h3>Skills Demonstrated</h3>

**Python:**
Applied Python and Pandas for data manipulation, cleaning, transformation, and preprocessing.

**SQL:**
Used SQL for filtering, aggregation, analysis, and extracting meaningful insights from structured data.

**ETL Workflow:**
Implemented an Extract, Transform, and Load workflow to move data from its raw form into an analysis-ready database.

**Data Cleaning:**
Prepared raw data by handling missing values, transforming columns, converting data types, and creating calculated fields.

**Problem Solving:**
Applied practical data preparation and analytical techniques to improve data quality and support reliable analysis.

<h3>How to Run This Project</h3>

### 1. Install Python

Make sure Python is installed on your system.

### 2. Install Required Libraries

Install the Python libraries required by the project:

```bash
pip install kaggle pandas sqlalchemy pyodbc
```

### 3. Dataset

The project includes `orders.csv`, which contains the retail order data used for the analysis.

The Python workflow also includes Kaggle API functionality for downloading the dataset programmatically.

### 4. Run the Python Analysis

You can use either of the following:

**Jupyter Notebook:**

```text
Order Data Analysis.ipynb
```

This notebook contains the data cleaning and preprocessing workflow.

**Python Script:**

```text
orders data analysis.py
```

This file contains the Python-based version of the data preparation workflow.

### 5. SQL Server

Load the processed order data into a SQL Server database.

The Python workflow uses SQLAlchemy and PyODBC to connect Python with SQL Server.

### 6. Run SQL Analysis

Open:

```text
SQLQuery3.sql
```

in SQL Server Management Studio and execute the queries against the project database.

<h3>Files in the Repository</h3>

**Order Data Analysis.ipynb**
Jupyter Notebook containing the data cleaning and preprocessing workflow.

**orders data analysis.py**
Python script containing the data preparation and SQL Server loading workflow.

**SQLQuery3.sql**
SQL queries used for analyzing the processed retail order data.

**orders.csv**
Raw retail order dataset used in the project.

**project architecture.png**
Visual representation of the project's end-to-end workflow.

**README.md**
Project documentation and setup instructions.

<h3>Key Insights from the Analysis</h3>

**1. Product Performance Analysis**
Analyzed product-level revenue and sales performance to understand product contribution and identify important revenue drivers.

**2. Customer Purchasing Trends**
Explored customer purchasing behavior to identify patterns that can support data-driven marketing and personalization strategies.

**3. Sales Trends Over Time**
Analyzed sales patterns across different time periods to support inventory planning and demand analysis.

**4. Customer Segmentation**
Examined customers based on purchase frequency and order value to support customer segmentation and targeted campaign strategies.

<h3>Why This Project Matters</h3>

This project demonstrates the practical application of an end-to-end data analytics workflow, starting with raw data and progressing through data cleaning, transformation, database integration, and SQL-based analysis.

It highlights practical experience with **Python, Pandas, SQL Server, SQLAlchemy, PyODBC, ETL processes, and data analysis**, while demonstrating how technical data workflows can be used to generate meaningful business insights.

<h3>Let's Connect</h3>

Feel free to explore the project and review the analysis workflow. If you have any questions, suggestions, or feedback about the project, I'd be happy to connect and discuss data analytics, Python, SQL, and related projects.
